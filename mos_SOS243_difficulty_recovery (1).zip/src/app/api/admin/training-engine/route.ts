import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { getSessionUser } from "@/lib/supabase/auth";
import {
  clampMeter,
  diagnosisTargets,
  distanceFromTarget,
  meterLabel,
  nextProblemMeter,
  nextStudentMeter,
  trainingTargets,
} from "@/lib/difficulty-meter";
import { problemSubunit } from "@/lib/subunit-key";
import { recordTrainingResult } from "@/lib/sos-training-result";

async function admin() {
  const user = await getSessionUser();
  return !user || ["student","parent"].includes(user.user_metadata?.role)
    ? null
    : { supabase: createClient() };
}

const compact=(v:unknown)=>String(v??"").replace(/\s+/g,"").toLowerCase();
const related=(a:unknown,b:unknown)=>{
  const x=compact(a),y=compact(b);
  return !!(x&&y&&(x.includes(y)||y.includes(x)));
};
const tableMessage=(m:string)=>m.includes("does not exist")
  ? "먼저 supabase-v3.1-subunit-difficulty-link.sql을 실행해 주세요."
  : m;

function score(problem:any,target:any){
  let value=0;
  const units=Array.isArray(target.units)?target.units:[];
  const types=Array.isArray(target.types)?target.types:[];
  const info=problemSubunit(problem);

  if(units.some((x:any)=>
    related(x.label,info.subunit) ||
    related(x.label,problem.unit) ||
    related(x.label,problem.topic)
  )) value+=70;

  const dna=JSON.stringify(problem.problem_dna??{});
  if(types.some((x:any)=>
    related(x.label,problem.topic) ||
    related(x.label,problem.question_type) ||
    related(x.label,dna)
  )) value+=30;

  return value;
}

function dnaTags(problem:any){
  const out:string[]=[];
  const visit=(value:any)=>{
    if(out.length>=6||value==null)return;
    if(typeof value==="string"){
      const v=value.trim();
      if(v&&v.length<=36&&!out.includes(v))out.push(v);
      return;
    }
    if(Array.isArray(value)){ for(const item of value)visit(item); return; }
    if(typeof value==="object"){ for(const value2 of Object.values(value))visit(value2); }
  };
  visit(problem?.problem_dna);
  return out.slice(0,4);
}

function outputText(payload:any){
  if(typeof payload?.output_text==="string") return payload.output_text.trim();
  const parts:string[]=[];
  for(const item of payload?.output??[]) for(const content of item?.content??[])
    if(typeof content?.text==="string") parts.push(content.text);
  return parts.join("\n").trim();
}

function aiTargetText(target:any){
  return [
    `과목: ${target?.sourceSubject??"미분류"}`,
    `대단원: ${target?.sourceMajorUnit??""}`,
    `중단원: ${target?.sourceMiddleUnit??""}`,
    `소단원: ${target?.sourceMinorUnit??target?.sourceUnit??""}`,
    `세부주제: ${target?.sourceDetailedTopic??""}`,
    `문항유형: ${target?.sourceQuestionType??""}`,
    `문제유형 태그: ${Array.isArray(target?.sourceProblemTypes)?target.sourceProblemTypes.join(", "):""}`,
    `난이도(1~8): ${target?.sourceDifficulty??""}`,
    `기존 분류: ${Array.isArray(target?.types)?target.types.map((x:any)=>x?.label).filter(Boolean).join(", "):""}`,
  ].join("\n");
}

function compactDnaForAi(problem:any){
  const dna=problem?.problem_dna??{};
  const basic=dna?.basic??{};
  const concept=dna?.concept??{};
  const thinking=dna?.thinking??{};
  const abilities=dna?.abilities??{};
  const summary=dna?.summary??{};
  const edu=dna?.educational_value??{};
  return {
    id:String(problem.id),
    subject:problem.subject??basic.subject??"",
    unit:problem.unit??"",
    topic:problem.topic??"",
    questionType:problem.question_type??basic.question_format??"",
    difficulty:Number(problem.difficulty??0)||null,
    meter:Number(problem.difficulty_meter??0)||null,
    basic:{major:basic.major_unit??"",middle:basic.middle_unit??"",minor:basic.minor_unit??"",detailed:basic.detailed_topic??""},
    coreConcepts:concept.core_concepts??concept.key_concepts??concept.primary_concepts??[],
    prerequisite:concept.prerequisite_concepts??[],
    thinkingTypes:thinking.thinking_types??thinking.process??[],
    abilities,
    oneLine:summary.one_line??summary.summary??"",
    trainingGoal:edu.training_goal??edu.training_goals??"",
  };
}

async function rankDiagnosisCandidatesWithAi(target:any, pool:any[]){
  const apiKey=process.env.OPENAI_API_KEY;
  if(!apiKey) throw new Error("OPENAI_API_KEY가 없습니다. AI 추천문항을 생성할 수 없습니다.");
  const model=process.env.OPENAI_ANALYSIS_MODEL||process.env.OPENAI_MODEL||"gpt-5-mini";
  const candidateData=pool.map(compactDnaForAi);
  const prompt=`당신은 MATHPOOH SOS 수학 진단문항 추천 엔진입니다.\n\n[타겟문항]\n${aiTargetText(target)}\n\n[후보 문제은행]\n${JSON.stringify(candidateData)}\n\n목표: 타겟문항에서 학생의 취약 원인을 진단하기에 가장 적합한 문제를 최대 10개 추천하세요.\n규칙:\n- 같은 과목을 최우선으로 유지합니다. 과목이 다른 문항은 추천하지 않습니다.\n- 단순 단원명 일치보다 실제 수학 개념, 조건 해석 방식, 풀이 사고과정, 요구 능력, Problem DNA의 유사성을 더 중요하게 봅니다.\n- 타겟이 복합개념이면 핵심 구성요소를 분리 진단할 수 있는 문항도 좋은 후보입니다.\n- 난이도는 진단이 가능하도록 약간의 분산은 허용하되 관련성이 우선입니다.\n- 관련성이 약한 문항으로 10개를 억지로 채우지 마세요. 충분히 관련된 문항만 반환하세요. 최소 3개가 없다면 있는 만큼만 반환합니다.\n- candidate id는 반드시 제공된 후보 id 중에서만 선택하세요.\n- relevance는 0~100. 60 미만은 반환하지 마세요.\n- stars는 1~5 정수이며 relevance와 진단가치를 함께 반영하세요.\n- reason은 한국어 한 문장으로, 왜 타겟문항 진단에 유효한지 구체적으로 씁니다.\n- 추천순으로 반환하세요.`;
  const response=await fetch("https://api.openai.com/v1/responses",{
    method:"POST",
    headers:{Authorization:`Bearer ${apiKey}`,"Content-Type":"application/json"},
    body:JSON.stringify({
      model,
      input:[{role:"user",content:[{type:"input_text",text:prompt}]}],
      reasoning:{effort:"medium"},
      text:{format:{type:"json_schema",name:"sos_diagnosis_recommendations",strict:true,schema:{
        type:"object",additionalProperties:false,required:["recommendations"],properties:{recommendations:{type:"array",maxItems:10,items:{
          type:"object",additionalProperties:false,required:["id","relevance","stars","reason"],properties:{
            id:{type:"string"}, relevance:{type:"integer",minimum:0,maximum:100}, stars:{type:"integer",minimum:1,maximum:5}, reason:{type:"string"}
          }
        }}}
      }}}
    }),
  });
  const payload=await response.json();
  if(!response.ok) throw new Error(payload?.error?.message||"AI 추천 연결에 실패했습니다.");
  const text=outputText(payload);
  if(!text) throw new Error("AI 추천 결과가 비어 있습니다.");
  let parsed:any;
  try{parsed=JSON.parse(text);}catch{throw new Error("AI 추천 결과 형식을 읽지 못했습니다.");}
  const allowed=new Set(pool.map((p:any)=>String(p.id)));
  const seen=new Set<string>();
  return (Array.isArray(parsed?.recommendations)?parsed.recommendations:[])
    .filter((r:any)=>allowed.has(String(r?.id))&&Number(r?.relevance)>=60&&!seen.has(String(r?.id))&&(seen.add(String(r?.id))||true))
    .slice(0,10)
    .map((r:any)=>({id:String(r.id),relevance:Math.round(Number(r.relevance)||0),stars:Math.max(1,Math.min(5,Math.round(Number(r.stars)||1))),reason:String(r.reason??"").trim()}));
}

function selectByMeter(pool:any[], targets:Array<{meter:number;role:string}>, used:Set<string>) {
  const selected:any[]=[];

  for(const target of targets){
    const candidate=pool
      .filter((p)=>!used.has(String(p.id)))
      .map((p)=>({
        ...p,
        meterDistance:distanceFromTarget(Number(p.meter),target.meter),
      }))
      .sort((a,b)=>
        a.meterDistance-b.meterDistance ||
        Number(b.match)-Number(a.match) ||
        String(a.id).localeCompare(String(b.id))
      )[0];

    if(!candidate) continue;
    used.add(String(candidate.id));
    selected.push({...candidate, role:target.role, targetMeter:target.meter});
  }

  return selected;
}

async function loadSubunitMeter(supabase:any, studentId:string, info:{subject:string;major:string;subunit:string;key:string}, fallback:number) {
  const result=await supabase
    .from("sos_student_subunit_meters")
    .select("id,difficulty_meter,sample_count")
    .eq("student_id",studentId)
    .eq("subunit_key",info.key)
    .maybeSingle();

  if(result.error) throw result.error;

  if(result.data) {
    return {
      id:String(result.data.id),
      meter:clampMeter(result.data.difficulty_meter,fallback),
      samples:Number(result.data.sample_count??0),
    };
  }

  const inserted=await supabase
    .from("sos_student_subunit_meters")
    .insert({
      student_id:studentId,
      subject:info.subject,
      major_unit:info.major,
      subunit:info.subunit,
      subunit_key:info.key,
      difficulty_meter:clampMeter(fallback,3),
      sample_count:0,
    })
    .select("id,difficulty_meter,sample_count")
    .single();

  if(inserted.error) throw inserted.error;

  return {
    id:String(inserted.data.id),
    meter:clampMeter(inserted.data.difficulty_meter,fallback),
    samples:Number(inserted.data.sample_count??0),
  };
}

export async function GET(request:Request){
  const ctx=await admin();
  if(!ctx)return NextResponse.json({message:"관리자 권한이 필요합니다."},{status:403});

  const studentId=new URL(request.url).searchParams.get("studentId");
  if(!studentId)return NextResponse.json({sessions:[],subunitMeters:[]});

  const [sessionResult,meterResult]=await Promise.all([
    ctx.supabase
      .from("sos_training_sessions")
      .select("*,sos_training_items(id,problem_id,item_order,item_role,is_correct,response_seconds,subunit_key,student_meter_before,student_meter_after,problem_meter_before,problem_meter_after)")
      .eq("student_id",studentId)
      .order("created_at",{ascending:false}),
    ctx.supabase
      .from("sos_student_subunit_meters")
      .select("subject,major_unit,subunit,subunit_key,difficulty_meter,sample_count,updated_at")
      .eq("student_id",studentId)
      .order("subject")
      .order("major_unit")
      .order("subunit"),
  ]);

  const error=sessionResult.error||meterResult.error;
  return error
    ? NextResponse.json({message:tableMessage(error.message)},{status:400})
    : NextResponse.json({
        sessions:sessionResult.data??[],
        subunitMeters:meterResult.data??[],
      });
}

export async function POST(request:Request){
  const ctx=await admin();
  if(!ctx)return NextResponse.json({message:"관리자 권한이 필요합니다."},{status:403});

  const body=await request.json();
  const studentId=String(body.studentId??"");
  const action=String(body.action??"");
  const target=body.target??{};

  if(!studentId)return NextResponse.json({message:"학생을 선택해 주세요."},{status:400});

  if(action==="cancel-session"){
    const sessionId=String(body.sessionId??"");
    if(!sessionId)return NextResponse.json({message:"취소할 진단·훈련 ID가 없습니다."},{status:400});

    const sessionResult=await ctx.supabase
      .from("sos_training_sessions")
      .select("id,status,phase")
      .eq("id",sessionId)
      .eq("student_id",studentId)
      .maybeSingle();

    if(sessionResult.error)return NextResponse.json({message:sessionResult.error.message},{status:400});
    if(!sessionResult.data)return NextResponse.json({message:"진단·훈련을 찾을 수 없습니다."},{status:404});

    const currentStatus=String(sessionResult.data.status??"");
    if(!["DRAFT","ASSIGNED"].includes(currentStatus))
      return NextResponse.json({message:"학생이 이미 시작한 진단·훈련은 취소할 수 없습니다."},{status:409});

    const itemDelete=await ctx.supabase.from("sos_training_items").delete().eq("session_id",sessionId);
    if(itemDelete.error)return NextResponse.json({message:itemDelete.error.message},{status:400});

    const sessionDelete=await ctx.supabase.from("sos_training_sessions").delete().eq("id",sessionId);
    if(sessionDelete.error)return NextResponse.json({message:sessionDelete.error.message},{status:400});

    return NextResponse.json({success:true,cancelled:sessionId});
  }

  // 관리자 수동 채점/검증용. 학생 화면 제출도 동일한 공통 엔진을 사용한다.
  if(action==="record-result"){
    const itemId=String(body.itemId??"");
    if(!itemId)return NextResponse.json({message:"훈련 문항 ID가 없습니다."},{status:400});
    try{
      const result=await recordTrainingResult({
        supabase:ctx.supabase,
        studentId,
        itemId,
        studentAnswer:String(body.studentAnswer??""),
        responseSeconds:Number(body.responseSeconds??0)||null,
      });
      return NextResponse.json({success:true,...result});
    }catch(error){
      return NextResponse.json({message:error instanceof Error?error.message:"난이도 미터 반영 실패"},{status:400});
    }
  }

  const {data:previous}=await ctx.supabase
    .from("sos_training_sessions")
    .select("id,phase,round_no,sos_training_items(problem_id)")
    .eq("student_id",studentId);

  const used=new Set<string>();
  if(action==="additional-diagnosis"){
    for(const s of previous??[])if(s.phase==="DIAGNOSIS")
      for(const i of s.sos_training_items??[])used.add(String(i.problem_id));
  }

  const {data:problems,error}=await ctx.supabase
    .from("problem_bank_questions")
    .select("id,title,problem_code,subject,unit,topic,difficulty,difficulty_meter,difficulty_meter_unique_students,difficulty_meter_origin,question_type,problem_dna,training_course,question_image_path")
    .eq("status","ACTIVE")
    .eq("content_role","TRAINING");

  if(error)return NextResponse.json({message:error.message},{status:400});

  const targetUnit=String(
    target?.subunit ||
    target?.sourceUnit ||
    target?.units?.[0]?.label ||
    ""
  ).trim();
  const targetSubject=String(
    target?.subject ||
    target?.sourceSubject ||
    ""
  ).trim();

  // 최초 진단은 자동 확정하지 않는다. 타겟과 연관도가 높은 후보를 최대 10개 보여주고
  // 관리자가 그중 정확히 3개를 선택한 뒤 학생에게 배정한다.
  if(action==="diagnosis-candidates"){
    const targetDifficulty=Number(target?.sourceDifficulty??0)||3;
    const all=(problems??[]).map((p:any)=>{
      const info=problemSubunit(p);
      const meter=clampMeter(p.difficulty_meter,Number(p.difficulty)||3);
      const baseMatch=score(p,target);
      const subjectMatch=!targetSubject?0:(related(targetSubject,info.subject||p.subject)?90:-300);
      const subunitMatch=!targetUnit?0:(related(targetUnit,info.subunit)?100:related(targetUnit,p.unit)||related(targetUnit,p.topic)?55:0);
      const diffMatch=Math.max(0,24-Math.abs((Number(p.difficulty)||meter)-targetDifficulty)*6);
      return {...p,subunitInfo:info,meter,prefilterScore:baseMatch+subjectMatch+subunitMatch+diffMatch};
    });

    // AI에게 보내기 전에는 과목을 강하게 고정하고, DNA/단원 기준으로 넓게 최대 50개만 추린다.
    const sameSubject=targetSubject?all.filter((p:any)=>related(targetSubject,p.subunitInfo?.subject||p.subject)):all;
    const basePool=(sameSubject.length>=3?sameSubject:all)
      .sort((a:any,b:any)=>Number(b.prefilterScore)-Number(a.prefilterScore)||Math.abs(Number(a.meter)-targetDifficulty)-Math.abs(Number(b.meter)-targetDifficulty)||String(a.id).localeCompare(String(b.id)))
      .slice(0,50);

    let recommendations;
    try{
      recommendations=await rankDiagnosisCandidatesWithAi(target,basePool);
    }catch(aiError){
      return NextResponse.json({message:aiError instanceof Error?aiError.message:"AI 추천문항 생성 실패"},{status:502});
    }

    const byId=new Map(basePool.map((p:any)=>[String(p.id),p]));
    const selected=recommendations.map((rec:any)=>({problem:byId.get(rec.id),rec})).filter((x:any)=>x.problem);
    const candidates=await Promise.all(selected.map(async({problem:p,rec}:any)=>{
      let imageUrl="";
      if(p.question_image_path){
        const signed=await ctx.supabase.storage.from("question-images").createSignedUrl(p.question_image_path,60*30);
        imageUrl=signed.data?.signedUrl??"";
      }
      return {
        id:String(p.id), title:p.title, problemCode:p.problem_code, subject:p.subject, unit:p.unit, topic:p.topic,
        difficulty:p.difficulty, meter:p.meter, questionType:p.question_type, match:rec.relevance, relevance:rec.relevance, stars:rec.stars, reason:rec.reason,
        subunit:p.subunitInfo?.subunit||p.unit||p.topic||"", majorUnit:p.subunitInfo?.major||"", dnaTags:dnaTags(p), imageUrl,
      };
    }));
    return NextResponse.json({candidates,total:candidates.length,targetUnit,targetSubject,ai:true});
  }

  if(action==="assign-diagnosis-selected"){
    const selectedIds=Array.isArray(body.problemIds)?body.problemIds.map(String).filter(Boolean):[];
    if(selectedIds.length!==3||new Set(selectedIds).size!==3)
      return NextResponse.json({message:"진단 문항을 정확히 3개 선택해 주세요."},{status:400});
    const chosen=(problems??[]).filter((p:any)=>selectedIds.includes(String(p.id)));
    if(chosen.length!==3)return NextResponse.json({message:"선택한 진단 문항 중 문제은행에서 찾을 수 없는 문항이 있습니다."},{status:409});
    // 학생에게는 관리자가 클릭한 순서가 아니라 난이도 낮은 문항부터 제시한다.
    // 8단계(1~8) -> 문항 바로미터 -> ID 순으로 안정적으로 정렬한다.
    chosen.sort((a:any,b:any)=>{
      const ar=Number(a.difficulty);
      const br=Number(b.difficulty);
      const aRank=Number.isFinite(ar)&&ar>0?ar:clampMeter(a.difficulty_meter,3);
      const bRank=Number.isFinite(br)&&br>0?br:clampMeter(b.difficulty_meter,3);
      return aRank-bRank || clampMeter(a.difficulty_meter,aRank)-clampMeter(b.difficulty_meter,bRank) || String(a.id).localeCompare(String(b.id));
    });
    const reference=chosen[0];
    const info=problemSubunit(reference);
    let meterRow;
    try{ meterRow=await loadSubunitMeter(ctx.supabase,studentId,info,Number(target.sourceDifficulty)||Number(reference.difficulty)||3); }
    catch(error){ return NextResponse.json({message:error instanceof Error?error.message:"학생 소단원 미터 조회 실패"},{status:400}); }
    const snapshot={...target,subject:info.subject,majorUnit:info.major,subunit:info.subunit,subunitKey:info.key,studentDifficultyMeter:meterRow.meter,studentDifficultyLabel:meterLabel(meterRow.meter),meterSystem:"sos8-subunit-dynamic-v1",manualDiagnosisSelection:true};
    const {data:session,error:sessionError}=await ctx.supabase.from("sos_training_sessions").insert({student_id:studentId,phase:"DIAGNOSIS",status:"ASSIGNED",target_snapshot:snapshot,parent_session_id:null,round_no:1,total_count:3}).select().single();
    if(sessionError||!session)return NextResponse.json({message:tableMessage(sessionError?.message||"생성 실패")},{status:400});
    const {error:itemError}=await ctx.supabase.from("sos_training_items").insert(chosen.map((p:any,index:number)=>({session_id:session.id,problem_id:p.id,item_order:index+1,item_role:`관리자 선택 진단 · ${problemSubunit(p).subunit||p.unit||"연관문항"}`,subunit_key:problemSubunit(p).key||info.key})));
    if(itemError){ await ctx.supabase.from("sos_training_sessions").delete().eq("id",session.id); return NextResponse.json({message:tableMessage(itemError.message)},{status:400}); }
    return NextResponse.json({success:true,session,selectedIds});
  }

  // 추가 진단/훈련 자동선정은 기존 소단원 기반 엔진을 사용한다.
  const sameSubunitPool=(problems??[])
    .map((p:any)=>{
      const info=problemSubunit(p);
      return {
        ...p,
        subunitInfo:info,
        meter:clampMeter(p.difficulty_meter,Number(p.difficulty)||3),
        match:score(p,target),
      };
    })
    .filter((p:any)=>{
      if(!p.subunitInfo?.subunit) return false;
      if(targetSubject && !related(targetSubject,p.subunitInfo.subject)) return false;
      if(!targetUnit) return p.match>0;
      return related(targetUnit,p.subunitInfo.subunit) && p.match>0;
    });

  if(!sameSubunitPool.length)
    return NextResponse.json({
      message:`같은 소단원에서 진단/훈련 문항을 찾지 못했습니다. 대상 소단원: ${targetUnit||"미지정"}`,
    },{status:409});

  const referenceProblem=sameSubunitPool
    .sort((a:any,b:any)=>Number(b.match)-Number(a.match))[0];

  const info=referenceProblem.subunitInfo;
  let meterRow;
  try {
    meterRow=await loadSubunitMeter(
      ctx.supabase,
      studentId,
      info,
      Number(target.sourceDifficulty)||Number(referenceProblem.difficulty)||3
    );
  } catch(error) {
    return NextResponse.json({message:error instanceof Error?error.message:"학생 소단원 미터 조회 실패"},{status:400});
  }

  const studentMeter=meterRow.meter;
  let selected:any[]=[];
  let phase="DIAGNOSIS";
  let roundNo=1;
  const parentSessionId=String(body.parentSessionId??"")||null;

  if(action==="generate-diagnosis"||action==="additional-diagnosis"){
    roundNo=action==="additional-diagnosis"
      ? Math.max(1,...(previous??[]).filter((s:any)=>s.phase==="DIAGNOSIS").map((s:any)=>Number(s.round_no)))+1
      : 1;
    selected=selectByMeter(sameSubunitPool,diagnosisTargets(studentMeter),used);
  }else if(action==="generate-training"){
    if(parentSessionId){
      const parent=await ctx.supabase
        .from("sos_training_sessions")
        .select("id,phase,status,correct_count")
        .eq("id",parentSessionId)
        .eq("student_id",studentId)
        .maybeSingle();
      if(parent.error)return NextResponse.json({message:parent.error.message},{status:400});
      if(!parent.data||parent.data.phase!=="DIAGNOSIS"||!["COMPLETED","PASSED"].includes(String(parent.data.status)))
        return NextResponse.json({message:"학생이 진단을 제출한 뒤 훈련을 생성해 주세요."},{status:409});
    }
    phase="TRAINING";
    selected=selectByMeter(sameSubunitPool,trainingTargets(studentMeter),used);
  }else{
    return NextResponse.json({message:"지원하지 않는 작업입니다."},{status:400});
  }

  const required=phase==="DIAGNOSIS"?3:10;
  if(selected.length<required)
    return NextResponse.json({
      message:`같은 소단원 문항 부족: ${selected.length}/${required}문항만 매칭됩니다. (${info.subunit})`,
      matched:selected.length,
      required,
      subunit:info.subunit,
      studentMeter,
    },{status:409});

  const snapshot={
    ...target,
    subject:info.subject,
    majorUnit:info.major,
    subunit:info.subunit,
    subunitKey:info.key,
    studentDifficultyMeter:studentMeter,
    studentDifficultyLabel:meterLabel(studentMeter),
    meterSystem:"sos8-subunit-dynamic-v1",
  };

  const {data:session,error:sessionError}=await ctx.supabase
    .from("sos_training_sessions")
    .insert({
      student_id:studentId,
      phase,
      status:"ASSIGNED",
      target_snapshot:snapshot,
      parent_session_id:parentSessionId,
      round_no:roundNo,
      total_count:required,
    })
    .select()
    .single();

  if(sessionError||!session)
    return NextResponse.json({message:tableMessage(sessionError?.message||"생성 실패")},{status:400});

  const {error:itemError}=await ctx.supabase
    .from("sos_training_items")
    .insert(selected.slice(0,required).map((p,index)=>({
      session_id:session.id,
      problem_id:p.id,
      item_order:index+1,
      item_role:`${p.role} · ${info.subunit} · 목표 ${p.targetMeter.toFixed(2)} / 문항 ${p.meter.toFixed(2)}`,
      subunit_key:info.key,
    })));

  if(itemError){
    await ctx.supabase.from("sos_training_sessions").delete().eq("id",session.id);
    return NextResponse.json({message:tableMessage(itemError.message)},{status:400});
  }

  return NextResponse.json({
    session,
    scope:info,
    studentMeter,
    studentDifficultyLabel:meterLabel(studentMeter),
    items:selected.slice(0,required),
  });
}
